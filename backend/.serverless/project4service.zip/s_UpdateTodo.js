
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'quyetnn1102',
  applicationName: 'project4application',
  appUid: 'GDwr6KbZj94XMTVZ4L',
  orgUid: '56b380ac-a8ce-478e-98a0-58b5434e8cfb',
  deploymentUid: '6a93edc9-abb2-475a-8400-d9c4a42868b1',
  serviceName: 'project4service',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'project4service-dev-UpdateTodo', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/updateTodo.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}